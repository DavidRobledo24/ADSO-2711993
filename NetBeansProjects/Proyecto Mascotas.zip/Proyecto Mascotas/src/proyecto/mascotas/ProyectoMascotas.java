package proyecto.mascotas;


public class ProyectoMascotas {

   
    public static void main(String[] args) {
       new tablaMascotas();
    }
    
}
